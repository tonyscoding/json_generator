import React from 'react';

const style_fix = {
	backgroundColor: 'white',
	
}

const style_change = {
	backgroundColor: 'yellow',
}

export const Field = (props) => {
    return (
      <div style = {style_fix}>
        {
            props.fieldinput ?
            <input value = {props.value} onChange = {props.inputChange} onBlur = {props.blur} autoFocus/>
            :
            <div onDoubleClick = {props.doubleClick} style = {style_change}>
            {props.value}
          </div>
        }
        {props.children}
      </div>
    )
  }


export default Field;